package com.example.demo.entity;

import jakarta.persistence.*;
import jdk.jfr.SettingDefinition;
import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Getter
public class Article {
    @Id //대표값 sql의 primary key
    @GeneratedValue(strategy = GenerationType.IDENTITY) // auto increment
    private Long id;
    @Column
    private String title;
    @Column
    private String content;


}
