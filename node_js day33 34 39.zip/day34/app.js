// path라는 라이브러리는 node.js 자체라이브러리인데 url 세부 페이지를 생성하는데 사용
const path = require('path');
//const fs = require('fs');
const express = require('express');
//const uuid = require('uuid');
// 별도 파일을 패키지와 같은 방법으로 읽어 들입니다
//const resData = require('./util/restaurant-data')
// 경로가 들은 라우트 코딩 파일을 불러옵니다
const defaultRoutes = require('./routes/default')
const restaurantRoutes = require('./routes/restaurants')

const port = 3000;
const app = express();

// ejs 사용관련 코드 추가
// ejs 파일은 views 폴더로 지정
app.set('views', path.join(__dirname, 'views'))
app.set('view engine', 'ejs')

app.use(express.static('public'));
app.use(express.urlencoded({extended: false}))

app.use('/', defaultRoutes)
app.use('/', restaurantRoutes)

// // express모듈을 실행해서 그 안의 get 명령어를 사용합니다
// app.get('/', function(req, res) {
//     //res 즉, 서버의 응답으로 index.ejs를 화면에 '렌더링'하라는 뜻입니다
//     res.render('index')
// })


// app.get('/restaurants', function(req, res) {
//     const storedRestaurants = resData.getStoredRestaurants();

//     res.render('restaurants', {
//         numberOfRestaurants: storedRestaurants.length,
//         restaurants: storedRestaurants,
//     })
// })

// app.get('/restaurants/:id', function(req, res) {
//     // 인터넷 유저가 세부주소영역인 id 부분을 클릭하여 정보를 '요청' 후 변수저장
//     const restaurantId = req.params.id;
//     const storedRestaurants = resData.getStoredRestaurants();

//     for (const restaurant of storedRestaurants) {
//     if ( restaurant.id === restaurantId) {
//     res.render('restaurant-detail', {restaurant: restaurant})
//     }
// }
// // restaurants/ 여기 세부주소 틀리게 입력하면 404오류 페이지 화면에 띄우기
//  res.render('404')   

// })



// app.get('/recommend', function(req, res) {
//     res.render('recommend')
// })


// app.post('/recommend', function(req,res) {
//     // 폼태그의 데이터를 restaurant변수에 저장
//     const restaurant = req.body;
//     restaurant.id = uuid.v4()
//     const Restaurants = resData.getStoredRestaurants();

//     Restaurants.push(restaurant);

//     resData.storeRestaurants(Restaurants)

//     res.redirect('/confirm')


// })


// app.get('/confirm', function(req, res) {
//     res.render('confirm')
// })

// app.get('/about', function(req, res) {
//     res.render('about')
// })
// 그 외의 주소도 틀리게 입력하면 404페이지 화면에 띄우기
app.use(function(req, res) {
    res.render('404')
})

app.use(function(error, req, res, next) {
    res.render('500')
})

app.listen(port, () => console.log(`${port}번으로 서버구동`))