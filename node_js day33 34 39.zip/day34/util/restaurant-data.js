// app.js에 아무리 필요한거 다 불러와도 별도 파일을 별도 파일대로 다시 모듈을 불러야합니다
const path = require('path');
const fs = require('fs');
// 여기서 ..은 한 폴더 상위로 가란 말입니다
const filePath = path.join(__dirname, '..', 'data', 'restaurants.json')

// 다음 모듈이 해당기능을 사용할 수 있도록 함수의 형태로 재구성함
function getStoredRestaurants() {
    // 불러온 json파일 경로를 가지고 파일을 읽고 해석
    const fileData = fs.readFileSync(filePath)
    const storedRestaurants = JSON.parse(fileData)
    // 해석된 데이터를 반환함
    return storedRestaurants
}

// 유저에게 입력받은 추가 데이터를 json파일에 기록하는 기능을 함수로 만듬
function storeRestaurants(xxx) {
    fs.writeFileSync(filePath, JSON.stringify(xxx));
}

// 만든 함수를 다른 코드가 불러서 쓰려면 export 구문으로 반출이 허용된 상태를 만들어야 함
module.exports = {
    getStoredRestaurants: getStoredRestaurants,
    storeRestaurants: storeRestaurants
}

