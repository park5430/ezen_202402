// 별도의 자바스크립트로 코드를 빼서 실행하려면 별도로 뺀만큼 모듈을 재선언합니다

const path = require('path');
const fs = require('fs');

const filePath = path.join(__dirname, '..', 'data', 'restaurants.json');

// json 데이터셋 내의 값을 읽어서 사용가능하게 해석해둔 코드 파트를 
// getStoredRestaurants 이라는 함수로 따로 뺐다. 이러면 
// 지금 코드안의 getStoredRestaurants 함수만 컴포넌트화 한 것임
function getStoredRestaurants() {
    const fileData = fs.readFileSync(filePath);
    const storedRestaurants = JSON.parse(fileData);

    return storedRestaurants;
}



function storeRestaurants(storableRestaurants) {
    // 입력받은 데이터를 json데이터에 저장하는 기능
    fs.writeFileSync(filePath, JSON.stringify(storableRestaurants))
}

// 별도 파일안의 결과들은 파일 밖으로 내보낸다는 명령어가 있어야
// 외부에서 지금 코드의 함수에 접근하여 사용할 수 있습니다
// export의 의미가 수출인데, 이해하셨을 겁니다.
module.exports = {
    getStoredRestaurants: getStoredRestaurants,
    storeRestaurants: storeRestaurants
  };
