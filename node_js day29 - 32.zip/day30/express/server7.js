// 웹서버 모듈과 세부주소 모듈을 불러옵니다
const express = require("express");
const url = require("url");

// express 모듈을 불러오고 사용할 포트번호를 변수화 합니다
const app = express();
const port = 3000;
// urlMap으로 세부주소를 관리하는 부분이 없어졌습니다
// 원하는 만큼 app.get 이면 전부 등록가능
// 두번째 특징은 end 대신 json으로 처리하면 utf-8이 기본으로 장착됩니다
// 그래서 html태그에서 아까 utf-8 부분의 사전 태그가 없어졌습니다
app.get("/", home);
app.get("/user", user);
app.get("/feed", feed);

app.listen(port, () => console.log("익스프레스로 라우터 리팩토링하기"))


// home, user, feed 3개의 함수 위치를 앞으로 옮긴 이유는 함수를 정의하고 사용해야 하는데
// 함수를 사용하는 위치가 먼저 와버려서 함수인식이 안되었음
// 이를 고치려면 화살표 함수 방식을 함수정의로 바꿔서 호이스팅을 열어두면 된다
function home(req, res) {
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.end("메인주소입니다")
}

function user(req, res) {
    // 아까 불러온 url 모듈에서 쿼리데이터 기능도 지원합니다
    // url모듈의 query함수를 이용해서 처리하면됩니다
    const userInfo = url.parse(req.url, true).query;
    res.end(`user name ===> name : ${userInfo.name}, age : ${userInfo.age}`);
}

function feed(req, res) {
    res.json(`
        <ul>
        <li>다국어되니1</li>
        <li>다국어되니1</li>
        <li>다국어되니1</li>
        </ul>`)
}



