// 웹서버 안에 세부주소 구현하기 예제
const http = require("http");
const url = require("url");

http.createServer((req, res) => {
    // 질문 - 왜 여기는 res 아니고 req인가????
    // 웹서비스 이용자가 세부경로를 입력하여
    // 세부경로안의 컨텐츠를 "요청"했기 때문
    // 불러온 url 모듈 기능으로 사용자의 세부주소에 대한
    // 요청을 처리할 수 있다
    const path = url.parse(req.url, true).pathname;
    // charset=utf-8는 한글을 포함하는 다국어 지원기능
    res.setHeader("Content-Type", "text/html; charset=utf-8" )
    // 사이트 안에서 user라는 세부주소를 입력하는 경우
    if (path === "/user") {
        res.end("user name ===> name : 디지털수업, age : 30");
    }
    // 사이트 안에서 feed라는 세부주소를 입력하는 경우
    else if (path === "/feed") {
        res.end(`<meta charset="UTF-8">
        <ul>
        <li>다국어되니1</li>
        <li>다국어되니1</li>
        <li>다국어되니1</li>
        </ul>`)
    }
    // 지정된 세부주소가 아닌 엄한 주소 입력 시
    else {
        res.statusCode = 404;
        res.end('404 에러입니다. 그런건 없어요 ^^');
    }
})
.listen("3000", () => console.log("경로를 지정할 수 있는 라우터를 만들어보자"));
