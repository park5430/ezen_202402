// if 절 안의 내용을 함수로 모듈화 해서
// 코드의 재사용을 하고자 하는 경우 (코드 리팩토링 예제)
const http = require("http");
const url = require("url");

http.createServer((req, res) => {
    const path = url.parse(req.url, true).pathname;
    res.setHeader("Content-Type", "text/html; charset=utf-8" )
    if (path === "/user") {
        user(req, res);
    }
    else if (path === "/feed") {
        feed(req, res);
    }
    else {
        else_kkk(req, res);
    }
})
.listen("3000", () => console.log("경로를 지정할 수 있는 라우터를 만들어보자"));

// 아래 출력 결과물을 네이버 웹툰의 쿼리데이터 원리를 사용하여 
// 쿼리데이터에 따른 달라진 컨텐츠를 출력할 수 있는가?
const user = (req, res) => {
    // 아까 불러온 url 모듈에서 쿼리데이터 기능도 지원합니다
    // url모듈의 query함수를 이용해서 처리하면됩니다
    const userInfo = url.parse(req.url, true).query;
    res.end(`user name ===> name : ${userInfo.name}, age : ${userInfo.age}`);
}

const feed = (req, res) => {
    res.end(`<meta charset="UTF-8">
        <ul>
        <li>다국어되니1</li>
        <li>다국어되니1</li>
        <li>다국어되니1</li>
        </ul>`)
}

const else_kkk = (req, res) => {
    res.statusCode = 404;
    res.end('404 에러입니다. 그런건 없어요 ^^');
}

