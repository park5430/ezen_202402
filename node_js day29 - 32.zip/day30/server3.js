// if 절 안의 내용을 함수로 모듈화 해서
// 코드의 재사용을 하고자 하는 경우 (코드 리팩토링 예제)
const http = require("http");
const url = require("url");

http.createServer((req, res) => {
    const path = url.parse(req.url, true).pathname;
    res.setHeader("Content-Type", "text/html; charset=utf-8" )
    if (path === "/user") {
        user(req, res);
    }
    else if (path === "/feed") {
        feed(req, res);
    }
    else {
        else_kkk(req, res);
    }
})
.listen("3000", () => console.log("경로를 지정할 수 있는 라우터를 만들어보자"));

const user = (req, res) => {
    res.end("user name ===> name : 디지털수업, age : 30");
}

const feed = (req, res) => {
    res.end(`<meta charset="UTF-8">
        <ul>
        <li>다국어되니1</li>
        <li>다국어되니1</li>
        <li>다국어되니1</li>
        </ul>`)
}

const else_kkk = (req, res) => {
    res.statusCode = 404;
    res.end('404 에러입니다. 그런건 없어요 ^^');
}

