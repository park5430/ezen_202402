// path라는 라이브러리는 node.js 자체라이브러리인데 url 세부 페이지를 생성하는데 사용
const path = require('path');
const fs = require('fs');
const express = require('express');
const port = 3000;
const app = express();

// ejs 사용관련 코드 추가
// ejs 파일은 views 폴더로 지정
app.set('views', path.join(__dirname, 'views'))
app.set('view engine', 'ejs')


// css 적용하는 코드임. public폴더를 인식하여 html이 css읽을 수 있게함
app.use(express.static('public'));

// urlencoded명령어로 json데이터 들어오면 해석해서 쓸 수 있게 하겠다
// {extended: false}는 urlencoded의 데이터 해석방식인데 false의 의미는 
// 별도의 해석 패키지를 부르지 않겠습니다. 자체 모듈로 해석할게요
// 자체 querystring 라이브러리 쓴다는 의미
app.use(express.urlencoded({extended: false}))

// express모듈을 실행해서 그 안의 get 명령어를 사용합니다
app.get('/', function(req, res) {
    //res 즉, 서버의 응답으로 index.ejs를 화면에 '렌더링'하라는 뜻입니다
    res.render('index')
})

// 음식점 개수 변수 정보를 restaurants.ejs에 보내준다
app.get('/restaurants', function(req, res) {
    // 현재까지의 restaurants.json파일 경로를 찾아내서 
    const filePath = path.join(__dirname, 'data', 'restaurants.json')
    const fileData = fs.readFileSync(filePath);
    // json 파일의 정보를 읽어낸다
    const storedRestaurants = JSON.parse(fileData)
    res.render('restaurants', {
        numberOfRestaurants: storedRestaurants.length,
        restaurants: storedRestaurants,
    })
})

app.get('/recommend', function(req, res) {
    res.render('recommend')
})

// recommend 페이지 안의 폼태그를 통해 데이터를 받아야 하므로
// 웹 api기능을 recommend 경로 안에 넣어서 데이터를 받을 수 있도록 조치한다
// api에서 글의 생성을 의미하는 post를 사용하여 데이터를 입력받아 json에 추가한다
app.post('/recommend', function(req,res) {
    // 폼태그의 데이터를 restaurant변수에 저장
    const restaurant = req.body;
    // restaurants.json를 읽어들임
    const filePath = path.join(__dirname, 'data', 'restaurants.json')
    const fileData = fs.readFileSync(filePath);
    // 현재까지의 json데이터를 해석하여 데이터 편집이 가능한 형태로 풀어놓습니다
    const storedRestaurants = JSON.parse(fileData)
    // 폼태그에서 읽은 restaurant데이터를 json데이터셋에 push로 추가합니다
    storedRestaurants.push(restaurant);
    // 추가된 데이터셋을 최종적으로 json파일안에 저장합니다
    fs.writeFileSync(filePath, JSON.stringify(storedRestaurants));

    res.redirect('/confirm')


})


app.get('/confirm', function(req, res) {
    res.render('confirm')
})

app.get('/about', function(req, res) {
    res.render('about')
})

app.listen(port, () => console.log(`${port}번으로 서버구동`))