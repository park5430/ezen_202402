// 이전 프라미스 기반 코드를 async 기반으로 변환해 보자
const axios = require("axios");
async function getTop20Movies() {
    const url = "https://raw.githubusercontent.com/wapj/musthavenodejs/main/movieinfo.json"
    try {
        // await로 서버 주소에서 데이터받아오는거 기다림
        const result = await axios.get(url);
        // 웹주소의 결과는 데이터 프로퍼티가 있다 (객체데이터 형식의 데이터값이 있다)
        const {data} = result;
        // data안의 articleList key가 없거나 그 key안의 값이 존재하지 않는 경우
        if (!data.articleList || data.articleList.size == 0) {
            throw new Error("역시 데이터는 없습니다")
        } 
        // 원하는 결과값인 영화제목과 순위를 map명령어를 통해서 뽑아내서 
        // 객체 데이터 재편성
        const movieInfos = data.articleList.map((article, idx) => {
            return { title: article.title, rank: idx +1};
        })
        // 정리된 데이터를 for문을 이용해 출력한다
        for (let movieInfo of movieInfos) {
            console.log(`[${movieInfo.rank}등] ${movieInfo.title}`);
        }
    }
    catch (err) {
        throw new Error(err);
    }
}

getTop20Movies()
