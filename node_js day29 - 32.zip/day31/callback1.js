//  회원가입 서비스를 가정합니다.
// 회원가입 데이터를 고객이 입력하면
// 1. 데이터를 우리서버 db에 저장하고
// 2. 이메일을 보내고
// 3. 성공메세지를 보내는 작업을 순차적으로 하려고 합니다
// 당연한 이야기이지만 데이터가 안들어왔는데 이메일을 보낼 수 없죠?
// 그래서 순차적인 작업이 되도록 우리가 조치해야합니다

const DB = []

// register라는 함수안에 세가지 작업을 수행합니다
function register(user) {
    // return문이 결과반환문인데 이전함수의 리턴값에서 다음함수가 시작하는걸 알수있다
    return saveDB(user, function(user) {
        return sendEmail(user, function(user) {
            return getResult(user);
        })
    })
}

// 이 함수는 push 명령어로 입력받은 데이터를 DB변수에 집어넣고 입력되었다고 메세지출력함
function saveDB(user, callback) {
    DB.push(user);
    console.log(`save ${user.name} to DB`);
    return callback(user);
}
// 이 함수는 이메일로 보내졌다고 메세지 출력해 줍니다
function sendEmail(user, callback) {
    console.log(`email to ${user.email}`);
    return callback(user);
}
// 이 함수는 마지막에 배치되었죠? callback구문이 없습니다 
// 이 함수의 결과를 참조할 다음 함수가 없으니까요
function getResult(user) {
    return console.log(`success register ${user.name}`);
}

const result = register({email: "sangjpar@gmail.com", password:"1234", name:"sangjin"})
console.log(result)
