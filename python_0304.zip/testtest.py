# -*- coding: utf-8 -*-
"""
Created on Thu Feb 22 18:43:04 2024

@author: EZEN-211T
"""

import profit2

print(profit2.revenue_breakdown(10000, 5000, 4000, 1000))
print(profit2.profit_calc(10000, 2000, 0.3, 1000))