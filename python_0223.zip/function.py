# -*- coding: utf-8 -*-
"""
Created on Thu Feb 22 18:38:42 2024

@author: EZEN-211T
"""

import profit2

print(profit2.revenue_breakdown(10000, 5000, 4000, 1000))