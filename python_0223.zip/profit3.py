# -*- coding: utf-8 -*-
"""
Created on Fri Feb 23 15:47:36 2024

@author: EZEN-211T
"""

def profit_calc(revenue, cost, tax, dividend):
    x = (revenue - cost) * (1 - tax) - dividend
    return x