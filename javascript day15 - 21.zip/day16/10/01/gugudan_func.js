// 함수 = 코드 재사용을 위해 정의하는 코드블럭문이다

function gugudan(){ // 함수 시작
  for(let i = 1; i <= 9; i++){
    console.log(`3 * ${i} = ${3 * i}`);
  }  
} // 함수 끝

gugudan(); // gugudan 함수 호출
