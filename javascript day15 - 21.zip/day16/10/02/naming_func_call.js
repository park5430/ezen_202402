const gugudan = function naming(){
  for(let i = 1; i <= 9; i++){
    console.log(`3 * ${i} = ${3 * i}`);
  }  
};
naming(); // 함수 호출
