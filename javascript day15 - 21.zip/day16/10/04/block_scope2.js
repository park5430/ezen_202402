// 원래 자바스크립트는 함수 스코프를 가지고 있습니다
// 함수안에서만 지역범위, 전체범위를 따졌습니다 (변수선언이 var만 있던 시절)

// 그런데 ES6 버전으로 오면서 let, const는 함수 뿐 아닌
// 블록에서도 변수의 범위를 사용할 수 있습니다

// 예전 자바스크립트에서 함수를 기준으로 변수의 범위를 구분하는 것을
// 함수레벨 스코프라고 합니다
// function aa() {
//   var kk = 10;
//   console.log(kk); // 함수 내부에서 kk 사용 가능
// }
// console.log(kk); // 함수 외부에서 kk 사용 불가능 (에러남)

var r = 1;
if (true) {
  // var 로 선언된 변수 r은 함수기준으로 범위를 지정하니까
  // 얘는 스코프 적용을 못받아서 전역변수 취급받고
  // var r = 1; 을 1111로 덮어 써버림 (변수 재선언)
  var r = 1111;
}
console.log(r);


// 함수레벨 스코프를 가지는 var와 블록레벨 스코프를 가지는 let, const 
if (true) {
  var y = 20; // 블록 내에서 선언된 변수
  let z = 30; // 블록 스코프를 가지는 변수 (ES6 이후)
  const w = 40; // 블록 스코프를 가지는 상수 (ES6 이후)
  console.log(y); // 20 출력
  console.log(z); // 30 출력
}

console.log(y); // 20 출력 (var는 함수 스코프를 따르지만, 블록 내에서도 접근 가능)
console.log(z); // 에러: z는 블록 외부에서 접근 불가 (let으로 선언된 변수는 블록 스코프를 가짐)
console.log(w); // 에러: w는 블록 외부에서 접근 불가 (const로 선언된 상수는 블록 스코프를 가짐)





// let a = 10;
// function kkk() {
//   let a = 20;
//   var b = 555;
//   console.log(`코드 블록 내부 a: ${a}`);
//   console.log(`코드 블록 내부 b: ${b}`);
// }
// kkk();
// console.log(`코드 블록 외부 a: ${a}`);
// // console.log(`코드 블록 내부 b: ${b}`);
