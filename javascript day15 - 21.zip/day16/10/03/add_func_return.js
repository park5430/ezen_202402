// 함수안의 변수는 return문으로 반환해야 함수 밖에서 접근 가능합니다
// 그냥 덧셈결과 출력이랑 결과 "데이터 변수"를 반환하는 것은 다른 이야기입니다
// 자바스크립트의 this는 "나 자신" 즉 함수나 클래스 내부의 변수입니다
function sum(num11, num22){  
  // let result = num1 + num2; 
  // return result;
  this.num1 = num11;
  this.num2 = num22;
  return num1, num2;
}
const result = sum(10, 20);
console.log( num1 + num2); // out 30
