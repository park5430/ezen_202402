
// dan 이게 매개변수
function gugudan(dan){
  for(let i = 1; i <= 9; i++){
    console.log(`${dan} * ${i} = ${dan * i}`);
  }
}
// 매개변수에 집어넣은 값이 인수이다
// 지금 경우는 인수가 3이된다
gugudan(3);


gugudan(5);
gugudan(8);

// 화살표 함수 정의 할 때 매개변수가 1개면 안에 괄호 생략 가능
const summ = num1 => {
  console.log(num1);
}


