// 함수외부로 데이터를 반환할 때는 return 문이 필요합니다

// function sum(num1, num2){
//   let result = num1 + num2;
//   console.log("inner: " + result);
// }
// sum(10, 20); // inner: 30

// 함수 내부에 선언된 result변수의 값을 밖에서 읽을수가 없습니다
// 변수가 정의되지 않았다고 말하며 변수에 접근이 안됩니다
function sum(num1, num2){
  let result = num1 + num2; 
}
sum(10, 20); 
console.log("out: " + result);  // ReferenceError: result not defined
