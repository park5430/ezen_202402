const pw = "124";
if(pw.length < 4){
  console.log("비밀번호는 최소 4자리 이상 입력해 주세요.");
}
