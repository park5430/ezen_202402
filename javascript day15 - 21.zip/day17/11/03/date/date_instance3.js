// 날짜 객체 안에 날짜를 "2022-12-25" 날짜 형식으로 써주면 잘맞는다


const date1 = new Date("2022-12-25"); // Sun Dec 25 2022 09:00:00 GMT+0900 (한국 표준시)
console.log(date1);
const date2 = new Date("2022/12/25/18:30:50"); // Sun Dec 25 2022 18:30:50 GMT+0900 (한국 표준시)
console.log(date2);