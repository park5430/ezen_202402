// 기본적인 산수계산 외에 로또기능에 필요한 난수생성
// 원주율, 벡터 등 골치아픈 수학 기능을 쉽게 처리하기 위해
// 미리 만들어 놓은 수학 계산용 계산툴을 math 객체라 합니다


const random = Math.random();
console.log(random); // 실행할 때마다 달라짐
