// break없는 케이스는 밑으로 끝까지 실행되는 것을 이용해서
// 같은 결과 케이스들을 하나의 break로 묶어서 코드 작성가능

let food = "melon";
switch (food) {
  case "melon":
  case "apple":
  case "banana":
    console.log("fruit");
    break;
  case "carrot":
    console.log("vegetable");
    break;
  default:
    console.log("It's not fruits and vegetables.");
    break;
}