let score = 90;
if(score >= 90 && score < 100){
  console.log("A++ 학점");
}
