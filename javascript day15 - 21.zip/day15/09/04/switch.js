// if 문과 유사한 조건문
// if보다 코드가 깔끔하다는 가독성의 장점이 있음
// switch의 단점: 범위로 비교불가!!!!!!
// only정수, 혹은 문자 데이터만 사용가능
// 모든 switch구문의 맨 밑에는 break가 들갑니다
// break를 빼먹으면 해당 케이스 밑으로 모든케이스를 실행하면서
// break가 있는 case를 만날때까지 멈추지않는다
// 맨 마지막 default 케이스만 break생략함

let food = "melon";
switch (food) {
  case "melon":
    console.log("멜론");
    // break;
  case "apple":
    console.log("사과");
    //break;
  case "banana":
    console.log("바나나");
    //break;
  case "carrot":
    console.log("당근");
    //break;
  default:
    console.log("이게뭐니????");
    break;
}

// if (food == "melon") {
//   console.log("멜론");
// } else if ((food = "apple")) {
//   console.log("사과");
// } else if ((food = "banana")) {
//   console.log("바나나");
// } else if ((food = "carrot")) {
//   console.log("당근");
// } else {
//   console.log("이게뭐니????");
// }
