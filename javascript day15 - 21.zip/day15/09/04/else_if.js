// if 에서 따져야할 조건이 여러가지라면?
// 예) 20000원보다 예산이 많으면 택시
// 15000원 광역버스
// 10000원 이상 따릉이 등등

let num = 16000;

// if(num > 20000){
//   console.log("택시");
// }
// else if(num > 15000){
//   console.log("빨간버스")
// }
// else if(num > 10000){
//   console.log("따릉이")
// }
// else{
//   console.log("걍 걸어가자 ^^");
// }

// else if 없는 세상 ㅠㅠ
if (num > 20000) {
  console.log("택시");
} else {
  if (num > 15000) {
    console.log("빨간버스");
  } else {
    if (num > 10000) {
      console.log("따릉이");
    } else {
      console.log("걍 걸어가자 ^^");
    }
  }
}
