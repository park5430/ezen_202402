// 스위치는 범위비교가 안되므로 범위를 이용한 조건은 if문으로 작성하세요 ^^
// 조건이 정수로 명확하면 switch문이 적절합니다 참고해 주세요

let score = 90;
switch (score){
  case 90:    
  case 91:
  case 92:
  case 93:
  case 94:
  case 95:
  case 96:
  case 97:
  case 98:
  case 99:
    console.log("A++ 학점");
    break;
  default:
    break;
}
