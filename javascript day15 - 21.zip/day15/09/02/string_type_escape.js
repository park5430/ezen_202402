let string = '문자열은 큰따옴표(")나 작은따옴표(\')로 감싸면 됩니다.';
console.log(string);
