let studentScore = {
  koreanScore:80,
  englishScore:70,
  mathScore:90,
  scienceScore:60
};
// 표기방식은 아래처럼 두가지 중 하나 쓰면 됩니다 (key값으로 호출)
console.log(studentScore.koreanScore); // 80
console.log(studentScore['englishScore']); // 70

// 중괄호 안에 key와 value값으로 구성된 자료구조를
// 객체 리터럴이라 합니다 (파이썬의 딕셔너리)
// 객체 리터럴에서 데이터 접근은 객체.key값 입니다
