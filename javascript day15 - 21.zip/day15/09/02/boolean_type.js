let boolean1 = true;
let boolean2 = false;
console.log(boolean1); // true
console.log(boolean2); // false

// 참, 거짓으로만 나타나는 부울형 자료입니다
// while, if 등의 반복문에서 많이 쓰입니다