let empty ; 
let empty2 = null; 
console.log(empty); // undefined
console.log(empty2); // null

// undefined : 변수나 상수를 메모리 공간에 선언하면 반드시 
// 생성한 공간에 데이터를 할당 해야합니다
// 할당하지 않는 경우, 자바스크립트에서 임시로 
// 변수나 상수 공간에 데이터를 집어넣는데 이 때 할당값이 undefined입니다
// 자바스크립트의 undefined는 사용자가 임의로 정의해서 할당하는 자료형아님

// null : 변수나 상수를 선언한 후, 의도적으로 선언한 공간을 비워둘때 씁니다

