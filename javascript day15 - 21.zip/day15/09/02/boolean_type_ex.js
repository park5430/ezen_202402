let boolean1 = 10 < 20;
let boolean2 = 10 > 20;
console.log(boolean1); // true
console.log(boolean2); // false
