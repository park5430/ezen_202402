let string = '문자열' + " 연결 연산자";
console.log(string);

// 문자열 데이터는 + 사인으로 합칩니다
