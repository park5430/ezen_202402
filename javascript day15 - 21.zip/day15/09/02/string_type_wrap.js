let string1 = '문자열은 큰따옴표(")로 감싸면 됩니다.';
let string2 = "문자열은 작은따옴표(')로 감싸면 됩니다.";

console.log(10-'10')

// 자바스크립트 예시
// 밑에 코드 실행해 보세요 ^^
// 묵시적 형변환이라는 개념을 소개하였습니다.
console.log("3"*3)
console.log(3*"3")
console.log(1+"2"+1)
console.log(4 * [])
console.log(4 * [2])
console.log(4 + [2])
console.log(4 + [1,2])
console.log(4 * [1,2])