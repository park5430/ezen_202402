// 명시적 형변환
// 개발자가 "직접" 데이터 형태를 변환합니다
// 숫자 10을 String(num) 이렇게 처리해서
// '10'이란 글자로 바꿨습니다

let num = 10;
let strNum = "10";
if(String(num) === strNum){
  console.log(`똑같아요`);
}

