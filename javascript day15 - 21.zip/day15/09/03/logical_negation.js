let num = -10;
num = -num; 
console.log(num); // 10

console.log(10 == "10"); // 참
console.log(10 === "10"); // 거짓
// ==의 의미는 두 수의 값이 같느냐
// ---> 자바스크립트가 "10"을 임의로 변환해서 참이 나왔고
// ===의 의미는 값도 같으면서 자료형도 같냐
console.log(10 != "10");  // 거짓
console.log(10 !== "10"); // 참
