// 삼항 연산자
// x ? y : z
// x가 참이면 y를 반환하고 거짓이면 z를 반환합니다

let score = 90; 
let grade = score >= 90 ? 'A+' : 'B'; 
console.log(grade); // A+
