let arr = ["orange", "banana", "apple"];
for(let ㅌㅌㅌ in arr){
  console.log(ㅌㅌㅌ + ":---> " + arr[ㅌㅌㅌ]);
}