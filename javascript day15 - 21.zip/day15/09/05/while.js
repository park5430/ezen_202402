// while (조건) {
//   // 조건이 참인경우 다음의 코드블럭 실행
//   // 위 조건이 거짓이 될때까지 실행
// }

let num = 1;
while(num <= 9999){
  console.log(num);
  num++;
}

// 만일 1부터 9999를 하나씩 출력하고플때 반복문이 없다면
// console.log(1) ~~~ console.log(9999) 까지 9999번 타자 쳤을 것이다
