// 2중 for문 설명
// 바깥 for문 원소 당, 안쪽 for문의 모든 원소가 반복됩니다
// i: 0 ---> k: 0, 1, 2
// i: 1 ---> k: 0, 1, 2
for(let i = 0; i < 2; i++){
  console.log(`i: ${i}`);
  for(let k = 0; k < 3; k++){
    console.log(`k: ${k}`);
  }
}
