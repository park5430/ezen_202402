// 데이터에 직접 접근해서 개별 원소(프로퍼티)를 꺼냅니다

let obj = {
  name: "철수", 
  age: "20"
};
// obj이름의 객체는 name: "철수" & age: "20" 라는 
// 두개의 프로퍼티가 있습니다

for(let key in obj){
  console.log(key + ":---> " + obj[key]);
}
