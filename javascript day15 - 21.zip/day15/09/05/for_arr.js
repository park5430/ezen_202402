// for문은 데이터 베이스 안의 개별 데이터 원소에 접근하여 
// for문을 사용할 수 있습니다
// arr.length 가 데이터의 길이를 측정하는 명령어 인데
// 데이터가 3개이므로 i<arr.length는 i < 3과 같습니다

let arr = ["banana", "apple", "orange"];

for(let i=0; i<arr.length; i++){
  console.log(arr[i]);
}

let p=0;
while(p<3) {
  console.log(arr[p]);
  p++;
}
